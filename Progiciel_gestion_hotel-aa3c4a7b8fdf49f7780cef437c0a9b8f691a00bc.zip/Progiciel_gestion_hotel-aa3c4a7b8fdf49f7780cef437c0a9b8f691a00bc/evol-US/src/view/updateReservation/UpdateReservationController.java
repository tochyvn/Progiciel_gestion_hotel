package view.updateReservation;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class UpdateReservationController implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

}
