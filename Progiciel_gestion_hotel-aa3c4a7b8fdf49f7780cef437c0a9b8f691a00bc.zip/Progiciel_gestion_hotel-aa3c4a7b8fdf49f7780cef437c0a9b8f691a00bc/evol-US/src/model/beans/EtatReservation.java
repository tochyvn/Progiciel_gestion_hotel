package model.beans;

public enum EtatReservation {
	EXPIREE, ANNULEE, LIBEREE, EN_COURS
}
