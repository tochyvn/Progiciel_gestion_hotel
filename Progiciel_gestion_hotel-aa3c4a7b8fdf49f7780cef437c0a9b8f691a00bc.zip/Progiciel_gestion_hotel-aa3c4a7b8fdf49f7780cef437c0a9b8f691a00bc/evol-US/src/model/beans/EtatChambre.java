package model.beans;

public enum EtatChambre {
	MAINTENANCE, OCCUPEE, LIBRE, RESERVEE
}
