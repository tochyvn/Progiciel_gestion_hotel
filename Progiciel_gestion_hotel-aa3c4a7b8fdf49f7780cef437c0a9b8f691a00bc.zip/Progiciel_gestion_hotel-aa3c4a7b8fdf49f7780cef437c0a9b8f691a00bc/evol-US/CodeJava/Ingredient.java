import java.util.Collection;

public class Ingredient {

	private int idIngredient;

	private int libelle _ String;

	private double prix;

	private Collection<Plat> platIngredient;

}
