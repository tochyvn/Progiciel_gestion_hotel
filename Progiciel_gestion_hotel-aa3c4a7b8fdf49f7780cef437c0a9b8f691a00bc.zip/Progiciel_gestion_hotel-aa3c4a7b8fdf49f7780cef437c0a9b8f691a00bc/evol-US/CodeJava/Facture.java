import java.util.Date;
import java.util.Collection;

public class Facture {

	private int idFacture;

	private Date date;

	private Client client;

	private ModePaiement modePaiement;

	private Collection<LigneFacture> lignes;

	public void setIdFacture(int idFacture) {

	}

	public int getIdFacture() {
		return 0;
	}

	public void setDate(Date date) {

	}

	public Date getDate() {
		return null;
	}

}
