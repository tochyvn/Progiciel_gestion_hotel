public class PlatIngredient {

	private Plat plat;

	private Ingredient ingredient;

}
