import java.util.Collection;

public class Etat {

	private int idEtat;

	private String libelle;

	private Collection<Chambre> chambre;

	public void setIdEtat(int idEtat) {

	}

	public int getIdEtat() {
		return 0;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
