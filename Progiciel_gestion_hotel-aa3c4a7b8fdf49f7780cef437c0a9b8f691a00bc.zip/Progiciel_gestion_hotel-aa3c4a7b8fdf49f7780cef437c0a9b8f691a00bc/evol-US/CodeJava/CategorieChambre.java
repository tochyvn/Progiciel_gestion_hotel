import java.util.Collection;

public class CategorieChambre {

	private int idCategorie;

	private String libelle;

	private Collection<Chambre> chambre;

	public void setIdCategorie(int idCategorie) {

	}

	public int getIdCategorie() {
		return 0;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
