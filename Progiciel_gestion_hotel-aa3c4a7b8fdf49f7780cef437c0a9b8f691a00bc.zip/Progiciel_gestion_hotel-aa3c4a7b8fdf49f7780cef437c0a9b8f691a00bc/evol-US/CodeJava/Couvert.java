import java.util.Date;
import java.util.Collection;

public class Couvert extends Produit {

	private Date horaire;

	private Collection<Plat> platCouvert;

	private Collection<Menu> menuCouvert;

	public void setHoraire(Date horaire) {

	}

	public Date getHoraire() {
		return null;
	}

}
