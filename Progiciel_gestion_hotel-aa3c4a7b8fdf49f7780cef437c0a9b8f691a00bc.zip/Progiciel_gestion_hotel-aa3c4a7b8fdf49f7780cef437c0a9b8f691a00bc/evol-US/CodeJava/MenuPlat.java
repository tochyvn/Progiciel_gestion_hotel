public class MenuPlat {

	private Plat plat;

	private Menu menu;

}
