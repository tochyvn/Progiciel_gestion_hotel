public class Boisson extends Produit {

	private int idBoisson;

	private String libelle;

	private double prix;

	public void setIdBoisson(int idBoisson) {

	}

	public int getIdBoisson() {
		return 0;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
