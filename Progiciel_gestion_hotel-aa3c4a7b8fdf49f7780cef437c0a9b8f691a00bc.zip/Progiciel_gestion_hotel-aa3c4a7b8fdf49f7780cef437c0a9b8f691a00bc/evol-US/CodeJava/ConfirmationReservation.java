import java.util.Date;

public class ConfirmationReservation extends DemandeReservation {

	private Date dateConfirmation;

	private boolean confirmation;

	public void setDateConfirmation(Date dateConfirmation) {

	}

	public Date getDateConfirmation() {
		return null;
	}

	public void setConfirmation(boolean confirmation) {

	}

	public boolean isConfirmation() {
		return false;
	}

}
