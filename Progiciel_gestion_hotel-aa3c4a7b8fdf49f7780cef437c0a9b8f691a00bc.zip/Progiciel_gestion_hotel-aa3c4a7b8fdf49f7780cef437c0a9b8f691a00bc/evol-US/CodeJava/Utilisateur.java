public class Utilisateur extends Personne {

	private UserPosteDirection poste;

}
