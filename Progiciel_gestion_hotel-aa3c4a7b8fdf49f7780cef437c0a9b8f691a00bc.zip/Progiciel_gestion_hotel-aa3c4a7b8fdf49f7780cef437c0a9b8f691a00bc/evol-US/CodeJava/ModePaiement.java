import java.util.Collection;

public class ModePaiement {

	private int idMode;

	private String libelle;

	private Collection<Facture> facture;

	public void setIdMode(int idMode) {

	}

	public int getIdMode() {
		return 0;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
