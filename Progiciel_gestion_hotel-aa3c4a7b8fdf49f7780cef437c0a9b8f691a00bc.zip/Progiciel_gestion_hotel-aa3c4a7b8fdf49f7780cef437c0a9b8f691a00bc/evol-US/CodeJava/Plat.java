import java.util.Collection;

public class Plat {

	private int idPlat;

	private String libelle;

	private double prix;

	private Collection<Menu> menuPlat;

	private Collection<Couvert> platCouvert;

	private Collection<Ingredient> platIngredient;

}
