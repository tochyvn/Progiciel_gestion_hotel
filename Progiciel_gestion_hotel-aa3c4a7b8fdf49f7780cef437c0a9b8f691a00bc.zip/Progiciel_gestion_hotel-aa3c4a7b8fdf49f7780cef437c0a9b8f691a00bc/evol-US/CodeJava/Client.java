import java.util.Collection;

public class Client extends Personne {

	private String pays;

	private String cbNum;

	private String cbDateExp;

	private String cbCode;

	private Collection<DemandeReservation> demandeReservation;

	private Collection<Facture> facture;

	public void setPays(String pays) {

	}

	public String getPays() {
		return null;
	}

	public void setCbNum(String cbNum) {

	}

	public String getCbNum() {
		return null;
	}

	public void setCbDateExp(String cbDateExp) {

	}

	public String getCbDateExp() {
		return null;
	}

	public void setCbCode(String cbCode) {

	}

	public String getCbCode() {
		return null;
	}

}
