import java.util.Date;

public class DemandeReservation extends Produit {

	private Date dateArrivee;

	private Date dateSortie;

	private Client client;

	private Chambre chambre;

	public void setDateArrivee(Date dateArrivee) {

	}

	public Date getDateArrivee() {
		return null;
	}

	public void setDateSortie(Date dateSortie) {

	}

	public Date getDateSortie() {
		return null;
	}

}
