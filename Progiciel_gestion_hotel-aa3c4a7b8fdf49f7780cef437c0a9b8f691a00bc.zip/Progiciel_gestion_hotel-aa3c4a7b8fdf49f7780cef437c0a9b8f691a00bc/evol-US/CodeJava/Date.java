import java.util.Date;
import java.util.Collection;

public class Date {

	private Date date;

	private Collection<Chambre> tarif;

}
