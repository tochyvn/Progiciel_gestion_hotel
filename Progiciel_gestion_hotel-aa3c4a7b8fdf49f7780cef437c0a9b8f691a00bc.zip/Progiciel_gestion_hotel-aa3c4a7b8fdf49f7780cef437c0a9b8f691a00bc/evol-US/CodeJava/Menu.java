import java.util.Collection;

public class Menu {

	private int idMenu;

	private String libelle;

	private double prix;

	private Collection<Plat> menuPlat;

	private Collection<Couvert> menuCouvert;

}
