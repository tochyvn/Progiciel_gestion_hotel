public class Tarif {

	private int prix;

	private Date date;

	private Chambre chambre;

}
