public abstract class Produit {

	private int idProduit;

	private LigneFacture ligneFacture;

	public void setIdProduit(int idProduit) {

	}

	public int getIdProduit() {
		return 0;
	}

}
