public abstract class Personne {

	private int id;

	private String nom;

	private String prenom;

	private String adresse;

	private String codePostal;

	private String ville;

	private String login;

	private String password;

	public void setId(int id) {

	}

	public int getId() {
		return 0;
	}

	public void setNom(String nom) {

	}

	public String getNom() {
		return null;
	}

	public void setAdresse(String adresse) {

	}

	public String getAdresse() {
		return null;
	}

	public void setCodePostal(String codePostal) {

	}

	public String getCodePostal() {
		return null;
	}

	public void setVille(String ville) {

	}

	public String getVille() {
		return null;
	}

	public void setLogin(String login) {

	}

	public String getLogin() {
		return null;
	}

	public void setPassword(String password) {

	}

	public String getPassword() {
		return null;
	}

}
