public class PlatCouvert {

	private Plat plat;

	private Couvert couvert;

}
