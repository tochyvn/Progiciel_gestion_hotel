public class MenuCouvert {

	private Menu menus;

	private Couvert couverts;

}
