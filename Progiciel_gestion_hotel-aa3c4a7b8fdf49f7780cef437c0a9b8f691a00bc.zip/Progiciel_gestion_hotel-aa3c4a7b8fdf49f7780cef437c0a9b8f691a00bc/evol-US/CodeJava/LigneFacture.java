public class LigneFacture {

	private int idLigne;

	private int qte;

	private double tva;

	private Facture facture;

	private Produit produit;

	public void setIdLigne(int idLigne) {

	}

	public int getIdLigne() {
		return 0;
	}

	public void setQte(int qte) {

	}

	public int getQte() {
		return 0;
	}

	public void setTva(double tva) {

	}

	public double getTva() {
		return 0;
	}

}
