import java.util.Date;

public class Reparation {

	private int idReparation;

	private Date dateDebut;

	private Date dateFin;

	private String libelle;

	private Chambre chambre;

	public void setIdReparation(int idReparation) {

	}

	public int getIdReparation() {
		return 0;
	}

	public void setDateDebut(Date dateDebut) {

	}

	public Date getDateDebut() {
		return null;
	}

	public void setDateFin(Date dateFin) {

	}

	public Date getDateFin() {
		return null;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
