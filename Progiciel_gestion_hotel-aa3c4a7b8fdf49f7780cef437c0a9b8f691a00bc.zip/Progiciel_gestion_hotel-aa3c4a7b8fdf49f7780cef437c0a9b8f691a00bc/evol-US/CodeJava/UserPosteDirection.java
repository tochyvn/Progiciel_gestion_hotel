import java.util.Collection;

public class UserPosteDirection {

	private int idPoste;

	private String libelle;

	private Collection<Utilisateur> utilisateur;

	public void setIdPoste(int idPoste) {

	}

	public int getIdPoste() {
		return 0;
	}

	public void setLibelle(String libelle) {

	}

	public String getLibelle() {
		return null;
	}

}
